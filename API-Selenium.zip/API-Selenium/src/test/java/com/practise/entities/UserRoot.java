package com.practise.entities;
@lombok.Data
public class UserRoot {
    public int code;
    public String message;
    public Data_Res data;
}
