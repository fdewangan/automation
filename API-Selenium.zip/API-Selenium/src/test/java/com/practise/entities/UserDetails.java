package com.practise.entities;

import lombok.Data;

@Data
public class UserDetails {
    public String email;
    public int password;
}
