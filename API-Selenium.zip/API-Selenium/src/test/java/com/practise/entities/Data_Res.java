package com.practise.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;

@lombok.Data
public class Data_Res{
    @JsonProperty("Id")
    public int id;
    @JsonProperty("Name")
    public String name;
    @JsonProperty("Email")
    public String email;
    @JsonProperty("Token")
    public String token;
}