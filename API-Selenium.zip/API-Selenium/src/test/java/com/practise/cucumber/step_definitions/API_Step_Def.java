package com.practise.cucumber.step_definitions;

import io.cucumber.java.en.*;

import static com.practise.apiRequests.AdequateShopAPI.fetchAllUsers;
import static com.practise.apiRequests.GenerateToken.fetchDataFromJsonFile;
import static com.practise.apiRequests.GenerateToken.generateToken;

public class API_Step_Def {

    @Given("I am an authorized user")
    public void i_am_an_authorized_user() {
        fetchDataFromJsonFile();
        generateToken();
    }
    @Given("A list of users are available")
    public void a_list_of_users_are_available() {
        fetchAllUsers();
    }
    @When("Verify the user in the response")
    public void verify_the_user_in_the_response() {

    }

}
