package com.practise.cucumber.step_definitions;

import com.practise.pages.LoginPage;
import com.practise.webDriverConfig.WebDriverLibrary;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

import static com.practise.common.ExtentReportManager.endTest;
import static com.practise.common.ExtentReportManager.initReports;
import static com.practise.webDriverConfig.WebDriverLibrary.driver;

public class Home_Page_Step_Def {
    public LoginPage loginPage;

    @Given("I navigate to the login page")
    public void iNavigateToTheLoginPage() {
        loginPage = new LoginPage(driver);
        System.out.println("Launching the Browser");
    }

    @Before()
    public void setUp() {
        WebDriverLibrary.initiateDriver();
        System.out.println("This will run before the Scenario");
        initReports();

    }

    @After()
    public void cleanUp() {
        WebDriverLibrary.closeBrowser();
        System.out.println("This will run after the Scenario");
        endTest();

    }

    @Given("^user navigates to the website sauceDemo$")
    public void user_navigates_to_the_website_sauceDemo() throws Throwable {
        loginPage.navigateToSauceDemo();
    }

    @Given("^There user logs in through Login Window by using Username as \"(.*?)\" and Password as \"(.*?)\"$")
    public void There_user_logs_in_through_Login_Window_by_using_Username_as_and_Password_as(String userName, String password) throws Throwable {
        loginPage.loginToSauceDemo(userName, password);
    }

    @Then("^login must be successful\\.$")
    public void login_must_be_successful() throws Throwable {
        loginPage.verifyLogin();

    }


}
