package com.practise.cucumber.runners;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
@CucumberOptions(
        features = "src/test/resources/features/"
        , glue = {"com.practise.cucumber.step_definitions"},
        plugin = {
                "pretty",
                "html:target/cucumber-reports/cucumber-reports.html",
                "json:target/cucumber-reports/cucumber-reports.json"
        }
        , monochrome = true,
        tags = "@API"
)

public class TestRunner extends AbstractTestNGCucumberTests {
    //Integrate Test NG with Cucumber:- (AbstractTestNGCucumberTests) This class will be empty no need to add manually just we need write like :-extends AbstractTestNGCucumberTests
    //We need to add dependency for cucumber testng and testng so that :- import io.cucumber.testng.CucumberOptions;
        // Only selenium-java && cucumber-java && testng && cucumber-testng these 4 dependencies is required
        // We need to add the .xml and we need to give runner class path in .xml file
}
