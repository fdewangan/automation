package com.practise.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import static com.practise.constants.FilePathConstants.USER_DETAILS;
import static com.practise.webDriverConfig.WebDriverLibrary.driver;

public class CommonUtils {
  public static  Properties properties;
  public static ObjectMapper objectMapper;
    public static String node;
    private static String filePath="D:\\PersonalAutomation\\API-Selenium\\src\\test\\resources\\data.properties";

    //In this class we need to write wait methods for all selenium
    // Screenshot
    //common scroll
    //Excel sheet

    public static void readDataFromJson(String jsonPath)
    {
        try {
             objectMapper = new ObjectMapper();
             node = IOUtils.toString(new FileInputStream(jsonPath));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    public static void takeScreenShot(String text){
        try {
            TakesScreenshot screenshot = (TakesScreenshot) driver;
            File source = screenshot.getScreenshotAs(OutputType.FILE);
            String path=CommonUtils.extractData("screenshotPath");
            System.out.println(path);
            FileUtils.copyFile(source, new File(CommonUtils.extractData("screenshotPath") + text + ".png"));
        }catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public static String extractData(String data)  {
        try {
            FileInputStream fis = new FileInputStream(filePath);
            properties = new Properties();
            properties.load(fis);
            return properties.getProperty(data);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
