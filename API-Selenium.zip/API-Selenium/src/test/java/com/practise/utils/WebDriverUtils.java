package com.practise.utils;

import org.openqa.selenium.WebElement;

import static org.junit.Assert.assertNotNull;

public class WebDriverUtils {


    //common action methods
    // Select methods
    //common click and send keys methods


    public static void clickElement(WebElement element) {
        assertNotNull("Element should not be null for click", element);
        element.click();
    }

    public static void enterText(WebElement element, String text) throws Exception {
        element.clear();
        element.sendKeys(text);
    }

    public static String getText(WebElement element){
        String text = element.getText();
        return text;
    }
}
