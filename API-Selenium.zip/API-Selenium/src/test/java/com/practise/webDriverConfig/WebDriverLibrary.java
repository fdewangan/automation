package com.practise.webDriverConfig;
import com.practise.utils.CommonUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


public class WebDriverLibrary {

    public static WebDriver driver;

    public WebDriverLibrary(WebDriver driver) {
        WebDriverLibrary.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public static void initiateDriver() {
        System.setProperty("webdriver.chrome.driver",CommonUtils.extractData("driverPath"));
        driver = new ChromeDriver();
    }

    public static void closeBrowser() {
        driver.quit();
    }
}
