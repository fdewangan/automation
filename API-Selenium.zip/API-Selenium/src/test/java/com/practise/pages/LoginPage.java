package com.practise.pages;


import com.practise.utils.CommonUtils;
import com.practise.utils.WebDriverUtils;
import com.practise.webDriverConfig.WebDriverLibrary;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage extends WebDriverLibrary {
    @FindBy(xpath = "//input[@placeholder='Username']")
    private WebElement userName;

    @FindBy(xpath = "//input[@placeholder='Password']")
    private WebElement password;

    @FindBy(how = How.XPATH, using = "//input[@name='login-button']")
    public WebElement clickToLogin;

    @FindBy(how = How.XPATH, using = "//div[text()='Swag Labs']")
    public WebElement swagLabs;

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public void navigateToSauceDemo() {
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();
    }

    public void loginToSauceDemo(String userN, String pass) throws Exception {
        WebDriverUtils.enterText(userName,userN);
        WebDriverUtils.enterText(password,pass);
        WebDriverUtils.clickElement(clickToLogin);
    }

    public void verifyLogin() {
       String text= WebDriverUtils.getText(swagLabs);
       System.out.println(text);
       CommonUtils.takeScreenShot("HomePage");

    }
}
