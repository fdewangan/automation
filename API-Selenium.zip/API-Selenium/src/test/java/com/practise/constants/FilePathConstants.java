package com.practise.constants;

public class FilePathConstants {

    public static final String USER_DETAILS_PATH="D:\\PersonalAutomation\\API-Selenium\\src\\test\\resources\\dataSet\\userDetails.json";
}
