package com.practise.constants;

public class UrlConstants {
    public static final String ADEQUATE_SHOP_BASE_URI="http://restapi.adequateshop.com";
    public static final String ADEQUATE_SHOP_END_POINT="/api/authaccount/login";

    public static final String ADEQUATE_SHOP_USER_BASE_URI="http://restapi.adequateshop.com";

    public static final String ADEQUATE_SHOP_USER_END_POINT="/api/users?page=1";
}
