package com.practise.apiRequests;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.practise.entities.Data_Res;
import com.practise.entities.UserDetails;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static com.practise.constants.FilePathConstants.USER_DETAILS_PATH;
import static com.practise.constants.UrlConstants.ADEQUATE_SHOP_BASE_URI;
import static com.practise.constants.UrlConstants.ADEQUATE_SHOP_END_POINT;
import static com.practise.utils.CommonUtils.*;

public class GenerateToken {
    public static UserDetails userDetails;
    public static Data_Res data_res=new Data_Res();
    public static JsonNode root;
    static ObjectMapper mapper = new ObjectMapper();

    public static void fetchDataFromJsonFile() {
        try {
            readDataFromJson(USER_DETAILS_PATH);
            userDetails = objectMapper.readValue(node, UserDetails.class);
            //userDetails.setEmail("Developer" +Math.random()+"@gmail.com");
            //userDetails.setEmail("Developer35@gmail.com");
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

    }

    public static void generateToken(){
        try {
            RestAssured.baseURI = ADEQUATE_SHOP_BASE_URI;
            RequestSpecification requestSpecification = RestAssured.given();
            requestSpecification.header("Content-Type", "application/json");
            Response response = requestSpecification.body(userDetails).post(ADEQUATE_SHOP_END_POINT);
            root = mapper.readTree(response.getBody().asString());
            data_res.setToken(String.valueOf(root.get("data").get("Token")));
            System.out.println(root.get("data").get("Token"));
        } catch (JsonMappingException e) {
            throw new RuntimeException(e);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
