package com.practise.apiRequests;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.practise.entities.Data_Res;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static com.practise.apiRequests.GenerateToken.data_res;
import static com.practise.constants.UrlConstants.*;

public class AdequateShopAPI {
    static ObjectMapper mapper = new ObjectMapper();
    public static JsonNode root;
    public static void fetchAllUsers() {
        try {
            RestAssured.baseURI = ADEQUATE_SHOP_USER_BASE_URI;
            RequestSpecification requestSpecification = RestAssured.given();
            requestSpecification.header("Content-Type", "application/json");
            requestSpecification.header("Authorization", "Bearer"+data_res.getToken());
            System.out.println(data_res.getToken());
            Response response = requestSpecification.get(ADEQUATE_SHOP_USER_END_POINT);
            System.out.println(response.prettyPrint());
            root = mapper.readTree(response.getBody().asString());
            System.out.println(root);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
