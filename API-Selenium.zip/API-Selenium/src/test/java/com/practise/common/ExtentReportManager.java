package com.practise.common;


import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReportManager {
    public static ExtentHtmlReporter htmlReporter;
    public static ExtentReports extentReports;
    public static ExtentTest test;

    public static void initReports() {
        htmlReporter = new ExtentHtmlReporter("extent-report.html");
        extentReports = new ExtentReports();
        extentReports.attachReporter(htmlReporter);
        test = extentReports.createTest("YourTestName", "Description of your test");
    }
    public static void endTest() {

        extentReports.flush();
    }
    public static void info(String text)
    {
        test.log(Status.INFO,text);
    }
    public static void pass(String text)
    {
        test.log(Status.PASS,text);
    }
    public static void fail(String text)
    {
        test.log(Status.FAIL,text);
    }
}
